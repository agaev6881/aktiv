##########################################################################
#   0.0   -   General Information
##########################################################################
The loader can be detected and blocked by your antivirus. THIS IS A FALSE POSITIVE AND YOU ARE ADVISED TO DISABLE / UNINSTALL IT WHEN USING THE ACTIVATOR

Requirements .NET Framework 4.0.

DOWNLOAD .NET Framework 4.0 : http://www.microsoft.com/it-it/download/details.aspx?id=17718

By R@1n.

FIND ME :
- on Twitter: @Ra1nReLoader
- I'm back on Twitter with the account @Ra1nReLoader This is my original account! other accounts are fake! be careful!



##########################################################################
#   0.1   -   Index
##########################################################################
01. Restore
02. Activation Status
03. Activation Methods
04. Changes in Versions
05. Windows Treatment
06. Office Treatment
07. Visual Studio Treatment
08. Arguments / Debug / Pre-Activation
09. FAQs
10. Legal Notes
11. Thanks
##########################################################################



##########################################################################
#   01   -   Restore
##########################################################################
If the Loader fails, Follow these steps.

* Make Boot from the Windows installation CD
* Hold down SHIFT and press F10
* Enter "bootsect.exe / nt60 SYS / force" (without quotes)
* Restart your PC
* Re-run the above steps but enter "sfc / scannow" (without quotation marks) to restore eventual corrupt files

======
NOTE: If after the command "bootsect.exe / nt60 ALL / force" windows is not reset correctly, make sure to unplug any additional device (USB or other), and then try again.

======
NOTE 2: An alternative is to press the 'R' after the screen of your BIOS. If successful, you will see your boot menu. From the menu select "boot without a SLIC" or "Make boot without SLIC".

##########################################################################
#   02   -   Activation Status
##########################################################################
Have you installed the loader and do not know if Windows is genuine? Follow these steps.

* Check online by opening Internet Explorer and browsing http://www.microsoft.com/genuine/validate/


##########################################################################
#   03   -   Activation Methods
##########################################################################
The Loader By R@1n uses various methods for activating Windows.

* Antiwpa (Windows XP)
* OEM (Windows Vista, Windows 7, Windows Server 2008 (R2), Windows Server 2012 (R2), Windows Server 2016 RTM)
* KMS (Windows Vista, Windows 7, Windows 8.0, Windows 8.1, Windows 10, Windows Server 2008 (R2), Windows Server 2012 (R2), Windows Server 2016 RTM)

======
NOTE: The Re-Loader can also activate Office 2010, Office 2013 and Office 2016 with the KMS method.



##########################################################################
#   04   -   Changes in Versions
##########################################################################
Version 1.0 RC 1 (03/07/2017)
* First Release.

Version 1.0 RC 2 (05/07/2017)
* add Task.
* add /Silent argument.
* Bug fixes.

Version 1.0 RC 3 (06/07/2017)
* Fix bugs for office activation.
* minor Bug fixes.

Version 1.0 RC 4 (07/07/2017)
* more Intelligent Activation KMS algorithm.
* minor Bug fixes.

Version 1.0 RC 5 (08/07/2017)
* Faster certified installation.
* minor Bug fixes.

Version 1.0 RC 6 (14/07/2017)
* Updated the OEM logon installation system, Now it works like the old Re-Loader (/Logo=).
* Added spp fix.
* Added Windows certified installation.
* minor Bug fixes.

Version 1.0 RC 7 (15/07/2017)
* Faster Win certified installation.

Version 1.0 RC 8 (16/07/2017)
* Fix Win certified installation.
* Changed graphics.



##########################################################################
#   05   -   Windows Treatment
##########################################################################
The product key used, are provided by Microsoft itself: https://technet.microsoft.com/it-it/library/jj612867.aspx
The following versions of Windows can be activated with this Loader

Windows XP
* Home Edition SP3
* Professional SP3
* Media Center Edition 2005 SP3

Windows Vista
* Enterprise
* Enterprise N
* Business
* Business N
* Starter
* Home Basic
* Home Basic N
* Home Premium
* Ultimate

Windows 7
* Enterprise
* Enterprise N
* Enterprise E
* Starter
* Starter E
* Home Basic
* Home Premium
* Home Premium E
* Professional
* Professional N
* Ultimate
* Ultimate E
* Embedded POS Ready
* Embedded
* Embedded Thin PC

Windows 8
* Enterprise
* Enterprise N
* Core
* Core N
* Core ARM
* Core Country SpecIFic
* Core Single Language
* Professional
* Professional WMC
* Professional N

Windows 8.1
* Enterprise
* Enterprise N
* Professional
* Professional N
* Professional WMC
* Core
* Core Connected
* Core Connected N 
* Core Connected Single Language
* Core Connected Country Specific
* Professional Student
* Professional Student N
* Core ARM
* Core N
* Core Single Language
* Core Country Specific
* Embedded Industry A
* Embedded Industry E
* Embedded Industry

Windows 10
* Professional
* Professional N
* Education
* Education N
* Enterprise
* Enterprise N
* Enterprise 2015 LTSB
* Enterprise 2015 LTSB N
* Home
* Home N
* Home Single Language
* Home Country Specific
||//Win10 Pre-Release\\||
* Home Connected
* Home Connected N
* Home Connected Single Language
* Home Connected Country Specific
* Professional Student
* Professional Student N
* Professional 2015 LTSB
* Professional 2015 LTSB N
* Home ARM
* Professional WMC

Windows Server 2008
* ServerDatacenter
* ServerDatacenterV
* ServerEnterprise
* ServerEnterpriseV
* ServerEnterpriseIA64
* ServerStandard
* ServerStandardV
* ServerComputeCluster
* ServerWeb
* ServerSBSStandard
* ServerWinFoundation
* ServerHomeStandard
* ServerSolution
* ServerHomePremium

Windows Server 2008 R2
* ServerDatacenter
* ServerEnterprise
* ServerEnterpriseIA64
* ServerStandard
* ServerEmbeddedSolution
* ServerHPC
* ServerWeb
* ServerSBSPrime
* ServerSBSStandard
* ServerStorageStandard

Windows Server 2012
* ServerDatacenter
* ServerStandard
* ServerMultiPointPremium
* ServerMultiPointStandard
* ServerSolution
* ServerWinFoundation
* ServerStorageStandard
* ServerStorageWorkgroup

Windows Server 2012 R2
* ServerStandardCore
* ServerStandard
* ServerDatacenterCore
* ServerDatacenter
* SolutionCore
* Solution
* ServerCloudStorageCore
* ServerCloudStorage
* ServerStorageStandard

Windows Server 2016
* ServerStandard
* ServerDatacenter
* ServerAzureCor
* ServerSolution
* ServerCloudStorage



##########################################################################
#   06   -   Office Treatment
##########################################################################
The product key used, are provided by Microsoft itself: (Office 2013) https://technet.microsoft.com/it-it/library/dn385360.aspx
The following versions of Office can be activated with this Loader

Office 2010
* Access
* Excel
* Groove
* InfoPath
* OneNote
* Outlook
* PowerPoint
* ProjectPro
* ProjectStd
* ProPlus
* Publisher
* Standard
* VisioPrem
* VisioPro
* VisioStd
* Word

Office 2013
* Access
* Excel
* InfoPath
* Lync
* OneNote
* Outlook
* PowerPoint
* ProjectPro
* ProjectStd
* ProPlus
* Publisher
* Standard
* VisioPro
* VisioStd
* Word

Office 2016 / 365
* Access
* Excel
* OneNote
* Outlook
* PowerPoint
* ProjectPro
* ProjectStd
* ProPlus
* Publisher
* Skype for Business
* Standard
* VisioPro
* VisioStd
* Mondo
* Word



##########################################################################
#   07   -   Visual Studio Treatment
##########################################################################
The following versions of Visual Studio can be activated with this Loader

Visual Studio 2012 (11) Activation
* Ultimate

Visual Studio 2013 (12) Activation
* Ultimate
* Pro
* Premium

Visual Studio 2015 (14) Activation
* Enterprise
* Pro

Visual Studio 2017 (15) Activation
* Enterprise
* Pro



##########################################################################
#   08   -   Arguments / Debug / Pre-Activation
##########################################################################
Arguments are such that the Re-Loader is used in Debug mode or Pre-Activation.

/ActAuto
 Enable Windows and Office 2016/2013/2010 simultaneously.

/ActWindows
 Activate Windows not taking into account the Genuine factor.

/ActOffice
 Activate Office 2016/2013/2010.

/ActOEM
 When possible, proceed with Windows OEM Activation.

/ActVS
 Activate  Visual Studio KMS 2012/2013/2015/2017.

/UninstallOEM
 When possible, proceed to Uninstall Windows OEM Activation.

/ActWPA
 When possible, proceed to Install Windows WPA Patch Activation.

/UninstallWPA
 When possible, proceed to Uninstall Windows WPA Patch Activation.

/UninstallKMS
 Uninstall KMS.

/UninstallOEM
 Uninstall OEM SLIC and installation serial trial.

/UninstallWPA
 Uninstalling Antiwpa.

/NoRestart
 It does not restart when needed.

/RestorePoint
 Create a restore point before using the Re-Loader.

/RemoveWatermark
 Removes the Watermark for Windows (requires restart).

/DisableTelemetry
 Disable Keylogger Microsoft.

/Logo=
 If you create a folder called "OEMLogo" (without quotation marks) in the same folder where the Re-Loader is, provide a Logo.bmp Logo.reg and the Re-Loader will install your Personal Logo.

/Debug
 Create a file on the desktop that allows debugging.

/Silent
 Hide all Windows for this app.



======
NOTE 1: Since version 4.0.0 you can download a package of 121 logos samples ready to use.
======

======
Example use / Logo 1: Activator.exe / Logo = "AutoDetect" (so the Loader between their libraries if a logo is compatible with the system)
Example use / Logo 2: Activator.exe / Logo = "VMWare" (is forced to install the VMWare logo)

======
NOTE 2: For using the OEM Loader, insert a script named "SetupComplete.cmd" in the path "X: \ sources \ $ OEM $ \ $$ \ Setup \ SCRIPTS" of the Windows install DVD.



################################################## ########################
# 09 - FAQs
################################################## ########################
0. Windows Update:
Q: Can I install Microsoft updates after using this program?
A: When it will be available.

1. Permanent activation:
Q: This program makes the Microsoft products activated permanently?
A: The products can be activated with KMS. it can check reactivation every minute, then. The products and OEM are Antiwpa Activated forever.

2. Advance the calendar:
Q: If I carry on the calendar of 180 days, the product is not active, why?
A: The reactivation occurs every minute. You have to wait a minute after moving the date.

3. Virus:
Q: My antivirus seems crazy!
A: If you downloaded the file from another site, we do not know what they could have done more. Files downloaded from our website are false positives.

4. On-line / Off-line:
Q: Do I need an internet connection to use the program?
A: No, but having an active connection can access the automatic updates and communications.

5. Product is not active:
Q: I used the program, but my product is not active, why?
A: The reasons may be varied, for simplicity, if you can not activate your product, you should make use of a Clean Machine (Formatted) and one of the compatible products listed above.

6. Language:
Q: What languages ??are supported?
A: All languages ??are supported! The interface (GUI) now has a few languages, but the interface does not affect the correct functioning.



################################################## ########################
# 10 - Legal Notes
################################################## ########################
DISCLAIMER: Re-Loader, Office Pre-Activation Pack, OEM Logo Pack.

This program was not created so that "the end user" can benefit
it without possessing the necessary licenses and original of its software.
R @ 1n, however, believes that all should have the possibility to test it and to have
a backup of your licenses.

Also, it does not justify in any way the distribution of this program,
in other words do not justify the spread at any website, or P2P
in any other public place.
I ask that these releases are not popular at all.

R @ 1n I have nothing to do with the distribution of this
program, it's all done by third parties.
According to the laws that belong to the country where I reside,
it is not my responsibility what others decide to do with
these versions. However, let it be said clearly:

"NOT condone in any way the sale or distribution
of this program, this was never my intention. "

R @ 1n assumes no responsibility for any loss of data
or any errors that may occur in using these programs.
Keep in mind that you are using a third-party solution.

Note that the use of these software are legal in most
countries outside the United States, if and only if you have a
full copy of the program - so you can use these programs
for backup purposes, and only for them. It remains to be seen how
you are struck licensing agreements with the (EULA).
They can not replace national laws, remember that.

According to the "DMCA ACT" members of the United States, you do not have
rights to circumvent a copy protection. Attention, if
are using this software in an illegal manner, the maximum penalty
that you have you are equal to that you would steal the shrinkwrapped software
in a mall. Although the basic operation of R @ 1n does not reside
in the United States, and so I'm not tied to
The laws of the United States as:

* No Electronic Theft Act
* Digital Millenium Copyright Act
* The Patriot Act
* "Other laws of the United States"

You should always buy the software you use, or in place,
use open-source programs.

This Software NOT encourages piracy, which is an act UNLAWFUL,
as well as being a lack of respect towards those who dedicate time and effort
application development.

I do not assume responsibility for improper use,
that is NOT dedicated to a vision to study educational or informative.
With this I can tell you that I dedicate myself to NOT piracy in any way,
I care only to share and investigate all forms of system and evasion.

I disagree, in any form, software piracy and NOT
responsible for a eventale inappropriate or illegal use.



################################################## ########################
# 11 - Thanks
################################################## ########################
Thank: QAD, xinso, Hotbird64, nonosense, Nosferati87, Mikmik38, Cynecx, heldigard, Daz, Alphawaves, Nummer, vyvojar for various sources and work!

Here are thanked all the people who have supported the development in all its forms:

- fullstuff
- Zanna

Thanks for the translation:

- azroach (English)

Thanks to MDL STUFF: http://forums.mydigitallife.info/
Thanks to members on Twitter:RainReLoader

Thank you so much.
- On Twitter: RainReLoader
